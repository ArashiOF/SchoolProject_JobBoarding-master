<footer class="footer">
    <div class="container">
        <nav class="float-left">
        <ul>
            <a href="/home">
                {{ __('Acerca de nosotros') }}
            </a>
            </li>
            <li>
            <a href="/home">
                {{ __('Política de uso y privacidad') }}
            </a>
            </li>
        </ul>
        </nav>
    </div>
</footer>