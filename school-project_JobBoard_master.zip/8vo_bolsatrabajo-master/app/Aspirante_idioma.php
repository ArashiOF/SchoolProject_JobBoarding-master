<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aspirante_idioma extends Model
{
    //
}
