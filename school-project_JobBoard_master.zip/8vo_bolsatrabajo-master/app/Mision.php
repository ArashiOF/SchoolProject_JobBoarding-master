<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mision extends Model
{
    //
    protected $primaryKey = 'idmision';
    protected $table = 'misiones';
}
