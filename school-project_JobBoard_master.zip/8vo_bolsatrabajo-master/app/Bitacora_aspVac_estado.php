<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bitacora_aspVac_estado extends Model
{
    //
    protected $table = 'bitacora_aspVac_estados';
    public $timestamps = false;
}
