<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users_mision extends Model
{
    //
    protected $primaryKey = null;
    public $incrementing = false;
    protected $table = 'users_misiones';
}
