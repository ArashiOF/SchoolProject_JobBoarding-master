<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grupos_encuesta extends Model
{
    //
    protected $primaryKey = null;
    public $incrementing = false;
}
