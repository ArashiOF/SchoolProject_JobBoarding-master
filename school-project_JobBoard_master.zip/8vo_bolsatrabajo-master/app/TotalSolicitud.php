<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TotalSolicitud extends Model
{
    protected $table = 'totalsolicitudes';
}
